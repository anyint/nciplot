
/* include file for Android startup code */
extern "C" {
  void log_android(const char *prompt, const char * msg);
}

